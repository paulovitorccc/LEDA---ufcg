package adt.skipList;

public class SkipListImpl<T> implements SkipList<T> {

	protected SkipListNode<T> root;
	protected SkipListNode<T> NIL;

	protected int maxHeight;

	protected double PROBABILITY = 0.5;

	public SkipListImpl(int maxHeight) {
		this.maxHeight = maxHeight;
		root = new SkipListNode(Integer.MIN_VALUE, maxHeight, null);
		NIL = new SkipListNode(Integer.MAX_VALUE, maxHeight, null);
		connectRootToNil();
	}

	/**
	 * Faz a ligacao inicial entre os apontadores forward do ROOT e o NIL Caso
	 * esteja-se usando o level do ROOT igual ao maxLevel esse metodo deve
	 * conectar todos os forward. Senao o ROOT eh inicializado com level=1 e o
	 * metodo deve conectar apenas o forward[0].
	 */
	private void connectRootToNil() {
		for (int i = 0; i < maxHeight; i++) {
			root.forward[i] = NIL;
		}
	}

	@Override
	public void insert(int key, T newValue, int height) {

		SkipListNode[] novoNode = new SkipListNode[this.maxHeight];
		SkipListNode<T> node = this.root;

		for (int i = this.maxHeight - 1; i >= 0; i--) {
			while (node.getForward(i).getValue() != null && node.getForward(i).getKey() < key) {
				node = node.getForward(i);
			}
			novoNode[i] = node;
		}
		node = node.getForward(0);
		if (node.getKey() == key) {
			node.setValue(newValue);
		} else {
			if (height > this.maxHeight) {
				for (int i = this.maxHeight + 1; i >= height; i--) {
					novoNode[i] = this.root;
				}
				maxHeight = height;
			}
			node = new SkipListNode<T>(key, height, newValue);
			for (int j = 0; j < height; j++) {
				if (novoNode[j] != null){
					node.forward[j] = novoNode[j].getForward(j);
					novoNode[j].forward[j] = node;
				}
			}
		}

	}

	@Override
	public void remove(int key) {
		
		SkipListNode[] novoNode = new SkipListNode[this.maxHeight];
		SkipListNode<T> node = this.root;

		for (int i = this.maxHeight - 1; i >= 0; i--) {
			while (node.getForward(i).getValue() != null && node.getForward(i).getKey() < key) {
				node = node.getForward(i);
			}
			novoNode[i] = node;
		}
		node = node.getForward(0);
		if(node.getKey() == key){
			for(int i = 0; i < this.maxHeight; i++){
				if(novoNode[i].forward[i] != node){
					break;
				}
				novoNode[i].forward[i] = node.forward[i];
				
			}
		}
		
	}

	@Override
	public int height() {
		
		SkipListNode<T> node = this.root;
		int altura = 0;
		while(!node.getForward(0).equals(NIL)){
			if(node.getForward(0).height() > altura){
				altura = node.getForward(0).height();
			}
			node = node.getForward(0);
		}
		return altura;
		
	}

	@Override
	public SkipListNode<T> search(int key) {

		SkipListNode<T> node = this.root;

		for (int i = node.height() - 1; i >= 0; i--) {
			while (node.getForward(i).getValue() != null && node.getForward(i).getKey() < key) {
				node = node.getForward(i);
			}
		}
		node = node.getForward(0);
		if (node.getKey() == key) {
			return node;
		}else{
			return null;			
		}
	}

	@Override
	public int size() {
		
		return size(this.root) - 1;
		
	}

	private int size(SkipListNode<T> node) {
		
		if(node.equals(this.NIL)) return 0;
		
		return 1 + size(node.getForward(0));
		
	}

	@Override
	public SkipListNode<T>[] toArray() {
		
		SkipListNode[] novoNode = new SkipListNode[size()+2];
		SkipListNode<T> node = this.root;
		for (int j = 0; j < novoNode.length; j++) {
			novoNode[j] = node;
			node = node.forward[0];
		}
		return novoNode;
		
	}

}
