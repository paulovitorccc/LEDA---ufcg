package adt.avltree;

import adt.bst.BSTImpl;
import adt.bst.BSTNode;
import adt.bt.Util;

/**
 * 
 * Performs consistency validations within a AVL Tree instance
 * 
 * @author Claudio Campelo
 *
 * @param <T>
 */
public class AVLTreeImpl<T extends Comparable<T>> extends BSTImpl<T> implements AVLTree<T> {

	// TODO Do not forget: you must override the methods insert and remove
	// conveniently.

	// AUXILIARY
	protected int calculateBalance(BSTNode<T> node) {

		return height((BSTNode<T>) node.getLeft()) - height((BSTNode<T>) node.getRight());
	}

	// AUXILIARY
	protected void rebalance(BSTNode<T> node) {

		if (Math.abs(calculateBalance(node)) <= 1)
			return;

		if (isLeftPending(node) && !node.getLeft().getLeft().isEmpty()) {
			Util.rightRotation(node);
		} else if (isLeftPending(node) && node.getLeft().getLeft().isEmpty()) {
			Util.leftRotation((BSTNode<T>) node.getLeft());
			Util.rightRotation(node);
		} else if (isRightPending(node) && !node.getRight().getRight().isEmpty()) {
			Util.leftRotation(node);
		} else if (isRightPending(node) && node.getRight().getRight().isEmpty()) {
			Util.rightRotation((BSTNode<T>) node.getRight());
			Util.leftRotation(node);
		}

	}

	// AUXILIARY
	protected void rebalanceUp(BSTNode<T> node) {
		BSTNode<T> parent = (BSTNode<T>) node.getParent();
		while (!parent.isEmpty()) {
			rebalance(parent);
			parent = (BSTNode<T>) parent.getParent();
		}
	}

	private boolean isLeftPending(BSTNode<T> node) {
		int balanceNode = calculateBalance(node);
		if (balanceNode == 1)
			return true;
		return false;

	}

	private boolean isRightPending(BSTNode<T> node) {
		int balanceNode = calculateBalance(node);
		if (balanceNode == -1)
			return true;
		return false;

	}

	private boolean isBalanced(BSTNode<T> node) {
		int balanceNode = calculateBalance(node);
		if (balanceNode == 0)
			return true;
		return false;

	}

	private void insert(BSTNode<T> node, T element) {

		if (node.isEmpty()) {
			node.setData(element);
			node.setLeft(new BSTNode<T>());
			node.setRight(new BSTNode<T>());
			node.getLeft().setParent(node);
			node.getRight().setParent(node);
		} else {
			if (node.getData().compareTo(element) > 0) {
				insert((BSTNode<T>) node.getLeft(), element);
			} else {
				insert((BSTNode<T>) node.getRight(), element);
			}
			rebalance(node);
		}
	}

	@Override
	public void insert(T element) {

		if (this.root.isEmpty()) {
			this.root.setData(element);
			this.root.setLeft(new BSTNode<T>());
			this.root.setRight(new BSTNode<T>());
			this.root.setParent(new BSTNode<T>());
			this.root.getLeft().setParent(this.root);
			this.root.getRight().setParent(this.root);
		} else {
			insert(this.root, element);
		}

	}

	private void removeLeaf(BSTNode<T> node) {

		if (node.getParent().getRight().getData() == node.getData()) {
			node.getParent().setRight(new BSTNode<T>());
		} else {
			node.getParent().setLeft(new BSTNode<T>());
		}

	}

	private void removeGrauUm(BSTNode<T> node) {

		BSTNode<T> aux = null;

		if (node.getLeft().isEmpty()) {
			aux = (BSTNode<T>) node.getRight();
		} else {
			aux = (BSTNode<T>) node.getLeft();
		}

		if (node.getParent().getRight().getData() == node.getData()) {
			aux.setParent(node.getParent());
			node.getParent().setRight(aux);
		} else {
			aux.setParent(node.getParent());
			node.getParent().setLeft(aux);

		}

	}

	private void removeGrauDois(BSTNode<T> node) {

		BSTNode<T> aux = sucessor(node.getData());

		node.setData(aux.getData());
		if (aux.isLeaf()) {
			removeLeaf(aux);
		} else {
			removeGrauUm(aux);
		}

	}

}
