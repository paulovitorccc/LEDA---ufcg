package adt.bt;

import adt.bst.BSTNode;

public class Util {


	/**
	 * A rotacao a esquerda em node deve subir e retornar seu filho a direita
	 * @param node
	 * @return
	 */
	public static <T extends Comparable<T>> BSTNode<T> leftRotation(BSTNode<T> node) {
		
		BSTNode<T> noX = node;
		BSTNode<T> noY = (BSTNode<T>) node.getRight();
		BSTNode<T> noZ = (BSTNode<T>) noY.getRight();
		
		noY.setParent(noX.getParent());
		noX.setParent(noY);
		noX.setRight(noY.getLeft());
		noY.setLeft(noX);
		
		return (BSTNode<T>) noX.getRight();
		
	}

	/**
	 * A rotacao a direita em node deve subir e retornar seu filho a esquerda
	 * @param node
	 * @return
	 */
	
	public static <T extends Comparable<T>> BSTNode<T> rightRotation(BSTNode<T> node) {
		
		BSTNode<T> noX = node;
		BSTNode<T> noY = (BSTNode<T>) node.getLeft();
		BSTNode<T> noZ = (BSTNode<T>) noY.getLeft();
		
		noY.setParent(noX.getParent());
		noX.setParent(noY);
		noX.setLeft(noY.getRight());
		noY.setRight(noX);
		
		return (BSTNode<T>) noX.getLeft();
		
	}

	public static <T extends Comparable<T>> T[] makeArrayOfComparable(int size) {
		@SuppressWarnings("unchecked")
		T[] array = (T[]) new Comparable[size];
		return array;
	}
}
